from pathlib import Path
from PIL import Image, ImageOps, ImageDraw

root = Path('/home/ubuntu/amazon-ph-simulators/asset_pack/visual_frameworks')
files = sorted(root.glob('*.png'))
thumb_w, thumb_h = 620, 360
label_h = 42
cols = 2
rows = (len(files) + cols - 1) // cols
canvas = Image.new('RGB', (cols * thumb_w, rows * (thumb_h + label_h)), '#f7f8fa')

def fit(img, size):
    return ImageOps.contain(img.convert('RGB'), size, method=Image.Resampling.LANCZOS)

for i, path in enumerate(files):
    img = Image.open(path)
    thumb = fit(img, (thumb_w - 24, thumb_h - 24))
    x = (i % cols) * thumb_w + 12
    y = (i // cols) * (thumb_h + label_h) + 10
    canvas.paste(thumb, (x + (thumb_w - 24 - thumb.width)//2, y + (thumb_h - 24 - thumb.height)//2))
    draw = ImageDraw.Draw(canvas)
    draw.text((x, y + thumb_h + 4), path.stem, fill='#131921')

out = root.parent / 'visual_frameworks_contact_sheet.png'
canvas.save(out, optimize=True)
print(out)

# Amazon PH Simulators — Facilitator Toolkit

## Delivery rhythm

Use the same instructional rhythm across modules so learners know when to retrieve, observe, practice, defend, and reflect. Keep the simulator open during the demonstration; the deck frames the decision, while the simulator supplies the consequence.

| Segment | Suggested time | Instructor move | Learner evidence |
|---|---:|---|---|
| Retrieval | 5 min | Ask for the prior rule or formula without notes. | Individual response or whiteboard calculation |
| Explanation | 10 min | Teach one concept using the worked example. | Plain-language restatement |
| Demonstration | 15 min | Think aloud inside the relevant simulator. | Annotated decision sequence |
| Practice | 20 min | Release a fresh scenario to pairs. | Simulator result and written rationale |
| Debrief | 10 min | Compare evidence, actions, and trade-offs. | One defended decision |
| Exit ticket | 5 min | Ask one transfer question. | Short collected response |

## Demonstration protocol

Before acting, say what the account evidence shows and what it does not show. Name the hypothesis, change only one variable, state the guardrail, and set a review date. When a learner proposes a negative keyword, ask whether the term is irrelevant or simply underperforming with thin data. When a learner proposes a budget increase, ask whether profit and inventory support the decision and whether budget is actually the constraint.

## Debrief protocol

Use the sequence **See → Explain → Decide → Defend → Log**. “See” identifies the observed metric or listing condition. “Explain” distinguishes the likely driver from the fact. “Decide” selects the smallest defensible action. “Defend” names the expected effect and reversal condition. “Log” records the action, reason, and review date.

## Question bank

| Concept | Prompt |
|---|---|
| Marketplace | What must be true before paid traffic can help? |
| Funnel | Which stage is leaking: impressions, clicks, orders, or profit? |
| Money math | Which formula translates this observation into a decision? |
| Match types | What shopper intent does this match type permit? |
| Negatives | Is the term irrelevant, or is the evidence merely thin? |
| Launch | What is the purpose of this campaign in the learning sequence? |
| Bids | What evidence justifies changing the bid rather than the listing? |
| Optimization | What variable are you deliberately leaving unchanged? |
| Reporting | Can you explain the result in plain language? |
| Workflow | What action requires notification or approval? |

## Feedback sentence stems

Use specific, evidence-led feedback. “You correctly identified ____. Your inference needs stronger support because ____.” “The action is plausible, but the guardrail is missing; add ____.” “You changed two variables, so the next step is to restore causal clarity by ____.” “This negative candidate is relevant but thin; tell me what additional evidence you need before acting.”

## Instructor observation record

| Learner | Evidence cited | Decision quality | Math accuracy | Safety / permissions | Communication | Next coaching action |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |

## References

[1] [Amazon PH Simulators repository](https://github.com/projectamazonph/amazon-ph-simulators)

[2] [PPC Coach implementation](https://github.com/projectamazonph/amazon-ph-simulators/blob/master/ppc-coach.html)

[3] [Instructor guide source](https://github.com/projectamazonph/amazon-ph-simulators)

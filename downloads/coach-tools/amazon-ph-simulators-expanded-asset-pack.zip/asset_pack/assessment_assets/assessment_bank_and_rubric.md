# Amazon PH Simulators — Assessment Bank and Rubric

## Short-answer assessment bank

Use these items for retrieval checks, simulator debriefs, or written quizzes. Require learners to show the formula or evidence path when the question is numerical.

| # | Question | Expected answer |
|---:|---|---|
| 1 | What is the difference between organic and paid visibility? | Organic visibility is earned through relevance and performance; paid visibility is purchased through ad auctions and eligibility. |
| 2 | What does the Buy Box change about a PPC diagnosis? | If the offer is not eligible, traffic may not convert or may not serve as expected; check it before escalating bids. |
| 3 | Calculate CPC for $20 spend and 20 clicks. | $1 CPC. |
| 4 | Calculate CTR for 1,000 impressions and 5 clicks. | 0.5% CTR. |
| 5 | Calculate conversion rate for 5 clicks and 1 order. | 20%. |
| 6 | Calculate ACOS and ROAS for $20 spend and $100 sales. | 20% ACOS and 5 ROAS. |
| 7 | What does break-even ACOS represent? | The maximum advertising cost of sales allowed before contribution margin is exhausted. |
| 8 | Why separate keyword from search term? | The keyword is the targeting instruction; the search term is the shopper’s actual query. |
| 9 | When should a relevant search term move to Exact? | When it has sufficient evidence of relevance and performance to deserve controlled targeting. |
| 10 | When is a negative keyword safer than a bid reduction? | When the term is irrelevant or clearly attracts unwanted intent. |
| 11 | Why use an Auto campaign in a launch sequence? | To discover queries and signals that can inform controlled manual targeting. |
| 12 | Why change one variable at a time? | To preserve causal clarity and learn which intervention drove the result. |
| 13 | What is the first response to high impressions and low CTR? | Diagnose the listing hook—image, price, offer, or reviews—before buying more traffic. |
| 14 | What should a weekly report distinguish? | Observed result, likely driver, action taken, guardrail, and next checkpoint. |
| 15 | What is a Level 3 permission task? | A high-risk strategy or budget action that requires manager approval before execution. |

## Open-response scoring rubric

Score each response from 0 to 3. A 3 is accurate, evidence-led, appropriately cautious, and clearly communicated. A 2 is directionally correct but missing one supporting element. A 1 shows partial recognition but contains a material reasoning gap. A 0 is incorrect, unsupported, or unsafe.

| Dimension | 3 — Strong | 2 — Developing | 1 — Weak | 0 — Missing |
|---|---|---|---|---|
| Evidence | Names the relevant metric or listing condition and its data source. | Names the metric but not the source or comparison. | Uses vague evidence. | Gives no evidence. |
| Reasoning | Separates fact, inference, and hypothesis. | Mostly logical with one leap. | Mixes observation and assumption. | No defensible reasoning. |
| Action | Selects the smallest appropriate action. | Action is plausible but too broad. | Action is aggressive or poorly matched. | Action is unsafe or absent. |
| Process | States guardrail, review date, or permission boundary. | Includes one process control. | Process control is unclear. | Ignores process. |
| Communication | Explains the decision plainly and concisely. | Understandable but incomplete. | Hard to follow. | Not communicable. |

## Assessment gates

| Gate | Required evidence | Suggested response |
|---|---|---|
| Foundation | Module quizzes at 70%+ and assigned simulator at 75%+ | Permit the learner to progress to structure and targeting. |
| Controlled traffic | Modules 3–5 quiz and simulator evidence at the repository thresholds | Permit launch planning after a safe negative-keyword rationale. |
| Safe operation | Launch and optimization simulator evidence plus a change log | Permit reporting and workflow assessment. |
| Supervised readiness | Final exam target 85%+, capstone 85%+, report, log, permissions decision, and defended handoff | Permit supervised client work with continued review. |

## References

[1] [Curriculum manifest](https://github.com/projectamazonph/amazon-ph-simulators/blob/master/assets/curriculum-manifest.js)

[2] [PPC Coach implementation](https://github.com/projectamazonph/amazon-ph-simulators/blob/master/ppc-coach.html)

[3] [Student guide](https://github.com/projectamazonph/amazon-ph-simulators/blob/master/learn/guide.html)

# Amazon PH Simulators — Asset Pack Index

## Visual frameworks

| File | Teaching purpose | Modules |
|---|---|---:|
| `visual_frameworks/ppc_funnel.png` | Diagnose whether the leak is visibility, attention, conversion, or economics. | 0, 1, 5, 10 |
| `visual_frameworks/money_math_ladder.png` | Connect raw inputs to CPC, CTR, CVR, ACOS, ROAS, TACoS, and break-even ACOS. | 2 |
| `visual_frameworks/campaign_architecture.png` | Show portfolio → campaign → ad group → targeting → search-term evidence. | 3, 6 |
| `visual_frameworks/search_term_decision_tree.png` | Classify search terms into Exact, negative, lower-bid/repair, or watch. | 4, 8 |
| `visual_frameworks/weekly_operating_loop.png` | Teach observe → diagnose → hypothesize → change one variable → log → review. | 7, 9 |
| `visual_frameworks/permissions_ladder.png` | Separate independent, notify, and approval-required actions. | 11 |
| `visual_frameworks/reporting_narrative.png` | Convert metrics into a result → driver → action → guardrail → checkpoint story. | 10, 11 |

Each diagram has a matching `.mmd` source file so instructors or designers can edit labels without redrawing from scratch.

## Learner materials

| File | Use |
|---|---|
| `learner_materials/learner_workbook.md` | Six print-ready worksheets for economics, targeting, launch, harvesting, optimization, and reporting. |
| `learner_materials/scenario_cards.md` | Eight short decision cases for retrieval, paired practice, and debate. |

## Instructor materials

| File | Use |
|---|---|
| `instructor_materials/facilitator_toolkit.md` | Delivery rhythm, demonstration protocol, debrief method, question bank, and observation record. |
| `instructor_materials/change_log_template.md` | Controlled-change documentation with evidence, guardrails, permissions, and review date. |
| `instructor_materials/client_report_template.md` | Plain-language weekly report structure. |

## Assessment assets

| File | Use |
|---|---|
| `assessment_assets/assessment_bank_and_rubric.md` | Fifteen short-answer questions, open-response rubric, and progression gates. |

## Source alignment

The pack is aligned to the repository curriculum map, instructor guide, PPC Coach implementation, and curriculum manifest. It does not replace the live simulators; it prepares learners to use them deliberately and provides evidence artifacts for debrief and progression.
